﻿ // script.js

document.addEventListener('DOMContentLoaded', () => {
    const welcomeMessage = document.getElementById('welcome-message');
    welcomeMessage.classList.remove('hide');
});

document.getElementById('get-location').addEventListener('click', () => {
    if (navigator.geolocation) {
        navigator.geolocation.getCurrentPosition(showPosition, showError);
    } else {
        alert("La géolocalisation n'est pas supportée par ce navigateur.");
    }
});

document.getElementById('coordinates-form').addEventListener('submit', (event) => {
    event.preventDefault();
    const latitude = parseFloat(document.getElementById('latitude').value);
    const longitude = parseFloat(document.getElementById('longitude').value);
    if (isNaN(latitude) || isNaN(longitude)) {
        alert("Veuillez entrer des coordonnées valides.");
        return;
    }
    showPosition({ coords: { latitude, longitude } });
});

function showPosition(position) {
    const latitude = position.coords.latitude;
    const longitude = position.coords.longitude;
    
    document.getElementById('coordinates').textContent = `Latitude: ${latitude}, Longitude: ${longitude}`;
    document.getElementById('location-info').classList.remove('hide');
    
    // Simuler la récupération des spécifications de terrain agricole et du climat
    const specifications = getSoilSpecifications(latitude, longitude);
    const climateInfo = getClimateInfo(latitude, longitude);
    
    displaySpecifications(specifications);
    displayClimateInfo(climateInfo);
}

function getSoilSpecifications(latitude, longitude) {
    // Simuler les spécifications du sol
    return {
        soilType: 'Argileux',
        pH: 6.5,
        suitableCrops: ['Blé', 'Maïs', 'Soja']
    };
}

function getClimateInfo(latitude, longitude) {
    // Simuler les informations climatiques
    return {
        temperature: '20-30°C',
        rainfall: '1000-1500 mm/an',
        humidity: '60-70%'
    };
}

function displaySpecifications(specifications) {
    const specsContainer = document.getElementById('specifications');
    specsContainer.innerHTML = `
        <p>Type de sol: ${specifications.soilType}</p>
        <p>pH du sol: ${specifications.pH}</p>
        <p>Cultures adaptées: ${specifications.suitableCrops.join(', ')}</p>
    `;
}

function displayClimateInfo(climateInfo) {
    const climateContainer = document.getElementById('climate-info');
    climateContainer.innerHTML = `
        <p>Température: ${climateInfo.temperature}</p>
        <p>Précipitations: ${climateInfo.rainfall}</p>
        <p>Humidité: ${climateInfo.humidity}</p>
    `;
}

function showError(error) {
    switch(error.code) {
        case error.PERMISSION_DENIED:
            alert("L'utilisateur a refusé la demande de géolocalisation.");
            break;
        case error.POSITION_UNAVAILABLE:
            alert("Les informations de localisation ne sont pas disponibles.");
            break;
        case error.TIMEOUT:
            alert("La demande de localisation a expiré.");
            break;
        case error.UNKNOWN_ERROR:
            alert("Une erreur inconnue s'est produite.");
            break;
    }
}
